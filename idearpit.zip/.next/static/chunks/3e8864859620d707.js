__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/36643aec17527b16.js",
  "static/chunks/turbopack-00dd80a9b2d61bda.js"
])
