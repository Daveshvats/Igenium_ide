__turbopack_load_page_chunks__("/_error", [
  "static/chunks/17722e3ac4e00587.js",
  "static/chunks/36643aec17527b16.js",
  "static/chunks/turbopack-b58d50a2dd36f68a.js"
])
