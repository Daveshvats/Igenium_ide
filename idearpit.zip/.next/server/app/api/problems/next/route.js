var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/problems/next/route.js")
R.c("server/chunks/[root-of-the-server]__26ad207c._.js")
R.c("server/chunks/[root-of-the-server]__531fbcb9._.js")
R.c("server/chunks/[root-of-the-server]__b7571db7._.js")
R.m(60305)
R.m(31746)
module.exports=R.m(31746).exports
