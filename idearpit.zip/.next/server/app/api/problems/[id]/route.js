var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/problems/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__5232a7a4._.js")
R.c("server/chunks/[root-of-the-server]__531fbcb9._.js")
R.c("server/chunks/[root-of-the-server]__b7571db7._.js")
R.m(54612)
R.m(3621)
module.exports=R.m(3621).exports
