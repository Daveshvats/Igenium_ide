var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/problems/route.js")
R.c("server/chunks/[root-of-the-server]__082b3348._.js")
R.c("server/chunks/[root-of-the-server]__531fbcb9._.js")
R.c("server/chunks/[root-of-the-server]__b7571db7._.js")
R.m(88339)
R.m(6564)
module.exports=R.m(6564).exports
