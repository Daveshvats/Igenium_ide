var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/test-cases/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__7ea9dd59._.js")
R.c("server/chunks/[root-of-the-server]__531fbcb9._.js")
R.c("server/chunks/[root-of-the-server]__b7571db7._.js")
R.m(25677)
R.m(59770)
module.exports=R.m(59770).exports
