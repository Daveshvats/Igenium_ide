var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/users/[id]/disqualify/route.js")
R.c("server/chunks/[root-of-the-server]__b38f8cd1._.js")
R.c("server/chunks/[root-of-the-server]__531fbcb9._.js")
R.c("server/chunks/[root-of-the-server]__b7571db7._.js")
R.m(10639)
R.m(445)
module.exports=R.m(445).exports
