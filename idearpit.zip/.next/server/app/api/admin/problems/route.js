var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/problems/route.js")
R.c("server/chunks/[root-of-the-server]__9a564c4d._.js")
R.c("server/chunks/[root-of-the-server]__531fbcb9._.js")
R.c("server/chunks/[root-of-the-server]__b7571db7._.js")
R.m(22470)
R.m(50805)
module.exports=R.m(50805).exports
