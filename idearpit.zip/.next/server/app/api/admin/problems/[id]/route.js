var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/problems/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__b5ebd545._.js")
R.c("server/chunks/[root-of-the-server]__531fbcb9._.js")
R.c("server/chunks/[root-of-the-server]__b7571db7._.js")
R.m(37910)
R.m(35825)
module.exports=R.m(35825).exports
