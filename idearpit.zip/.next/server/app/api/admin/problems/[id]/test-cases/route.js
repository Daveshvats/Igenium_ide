var R=require("../../../../../../chunks/[turbopack]_runtime.js")("server/app/api/admin/problems/[id]/test-cases/route.js")
R.c("server/chunks/[root-of-the-server]__29fd144e._.js")
R.c("server/chunks/[root-of-the-server]__531fbcb9._.js")
R.c("server/chunks/[root-of-the-server]__b7571db7._.js")
R.m(9873)
R.m(31507)
module.exports=R.m(31507).exports
