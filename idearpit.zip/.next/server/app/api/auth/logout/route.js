var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/logout/route.js")
R.c("server/chunks/[root-of-the-server]__660cd8a7._.js")
R.c("server/chunks/[root-of-the-server]__531fbcb9._.js")
R.m(79543)
R.m(83932)
module.exports=R.m(83932).exports
