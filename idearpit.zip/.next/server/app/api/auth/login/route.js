var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/auth/login/route.js")
R.c("server/chunks/[root-of-the-server]__11132f81._.js")
R.c("server/chunks/[root-of-the-server]__531fbcb9._.js")
R.c("server/chunks/[root-of-the-server]__b7571db7._.js")
R.m(9606)
R.m(30450)
module.exports=R.m(30450).exports
