var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/leaderboard/route.js")
R.c("server/chunks/[root-of-the-server]__1bf2074a._.js")
R.c("server/chunks/[root-of-the-server]__531fbcb9._.js")
R.c("server/chunks/[root-of-the-server]__b7571db7._.js")
R.m(43536)
R.m(40194)
module.exports=R.m(40194).exports
