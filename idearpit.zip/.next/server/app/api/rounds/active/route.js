var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/rounds/active/route.js")
R.c("server/chunks/[root-of-the-server]__8072757e._.js")
R.c("server/chunks/[root-of-the-server]__531fbcb9._.js")
R.c("server/chunks/[root-of-the-server]__b7571db7._.js")
R.m(76676)
R.m(85545)
module.exports=R.m(85545).exports
