var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/submissions/route.js")
R.c("server/chunks/[root-of-the-server]__8d40d09d._.js")
R.c("server/chunks/[root-of-the-server]__531fbcb9._.js")
R.c("server/chunks/[root-of-the-server]__b7571db7._.js")
R.m(33544)
R.m(39471)
module.exports=R.m(39471).exports
