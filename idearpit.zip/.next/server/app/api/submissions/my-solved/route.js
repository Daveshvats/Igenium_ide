var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/submissions/my-solved/route.js")
R.c("server/chunks/[root-of-the-server]__92d28896._.js")
R.c("server/chunks/[root-of-the-server]__531fbcb9._.js")
R.c("server/chunks/[root-of-the-server]__b7571db7._.js")
R.m(47167)
R.m(97203)
module.exports=R.m(97203).exports
