var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/submissions/test/route.js")
R.c("server/chunks/[root-of-the-server]__901054f9._.js")
R.c("server/chunks/[root-of-the-server]__531fbcb9._.js")
R.c("server/chunks/[root-of-the-server]__b7571db7._.js")
R.m(92949)
R.m(97939)
module.exports=R.m(97939).exports
