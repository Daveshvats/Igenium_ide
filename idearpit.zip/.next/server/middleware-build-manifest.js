globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/e60ef129113f6e24.js",
      "static/chunks/737778e17f44384e.js",
      "static/chunks/turbopack-020ba4871f781112.js"
    ],
    "/_error": [
      "static/chunks/17722e3ac4e00587.js",
      "static/chunks/737778e17f44384e.js",
      "static/chunks/turbopack-de3eb5ae36db07c2.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/7f99d9304de7ffdc.js",
    "static/chunks/2b20782ca617e7fe.js",
    "static/chunks/bf7074b72595ad34.js",
    "static/chunks/8082ab48faca5ea1.js",
    "static/chunks/8de370c3cbabf345.js",
    "static/chunks/turbopack-4a6be88cde7c1203.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];